﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using emed.Models;
using CrystalDecisions.CrystalReports.Engine;


namespace emed.Controllers
{
    public class ReportController : Controller
    {
        // GET: Report
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AllSales()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            //var c = (from b in db.AllSales select b).ToList();
            var c = db.AllSales.ToList();

            AllSales rpt = new AllSales();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\AllSalesReport.pdf");

        }
        public ActionResult AllSalesAction()
        {
            return AllSales();

        }
        public ActionResult DailySales()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            //var c = (from b in db.DailySales select b).ToList();
            var c = (from b in db.DailySales select b).ToList();

            DailySales rpt = new DailySales();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\DailySalesReport.pdf");

        }
        public ActionResult DailySalesAction()
        {
            return DailySales();

        }
        //3rd
        public ActionResult ExpiredMedicine()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var c = (from b in db.ExpiredMedicines select b).ToList();

            ExpiredMedicine rpt = new ExpiredMedicine();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\ExpiredMedicineReport.pdf");

        }
        public ActionResult ExpiredMedicineAction()
        {
            return ExpiredMedicine();

        }
        public ActionResult GenderDiscrimination()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var c = (from b in db.GenderDiscriminations select b).ToList();

            GenderDiscrimination rpt = new GenderDiscrimination();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\GenderDiscriminationReport.pdf");

        }
        public ActionResult GenderDiscriminationAction()
        {
            return GenderDiscrimination();

        }

        
        public ActionResult ItemSoldByStaff()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var c = (from b in db.ItemSoldByStaffs select b).ToList();

            ItemSoldByStaff rpt = new ItemSoldByStaff();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\AllSalesReport.pdf");

        }
        public ActionResult ItemSoldByStaffAction()
        {
            return ItemSoldByStaff();

        }

        //MedicineInfo
        public ActionResult MedicineInfo()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var c = (from b in db.MedicineInfoes select b).ToList();

            MedicineInfo rpt = new MedicineInfo();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\MedicineInfoReport.pdf");

        }
        public ActionResult MedicineInfoAction()
        {
            return MedicineInfo();

        }

        public ActionResult StaffCount()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            //emed.Models.StaffCount c;
            var c = db.StaffCounts.ToList();

            StaffCount rpt = new StaffCount();
            rpt.Load();
            //rpt.SetDataSource(c);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\StaffCountReport.pdf");

        }
        public ActionResult StaffCountAction()
        {
            return StaffCount();

        }

        public ActionResult StaffInfo()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var e = db.StaffInfoes.ToList();

            StaffInfo rpt = new StaffInfo();
            rpt.Load();
            //rpt.SetDataSource(e);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\StaffCountReport.pdf");

        }
        public ActionResult StaffInfoAction()
        {
            return StaffInfo();

        }
        public ActionResult SupplierInfo()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            
            var e = db.SupplierInfoes.ToList();

            SupplierInfo rpt = new SupplierInfo();
            rpt.Load();
            
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\StaffCountReport.pdf");

        }
        public ActionResult SupplierInfoAction()
        {
            return SupplierInfo();

        }


        //number of items present in stock
        public ActionResult NoOfItem()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            
            var e = db.NoOfItemsInstocks.ToList();

            NoOfItemsInstock rpt = new NoOfItemsInstock();
            rpt.Load();
            
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\StaffCountReport.pdf");

        }
        public ActionResult NoOfItemAction()
        {
            return NoOfItem();

        }

        public ActionResult Monthlysales()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var e = db.Monthlysales.ToList();

            Monthlysales rpt = new Monthlysales();
            rpt.Load();
            //rpt.SetDataSource(e);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\MonthlysalesReport.pdf");

        }
        public ActionResult MonthlysalesAction()
        {
            return Monthlysales();

        }
        public ActionResult MedicineBySupplier()
        {
            emed.Models.DB53Entities db = new emed.Models.DB53Entities();
            //CrMVCApp.Models.Customer c;
            var e = db.MedicineBySuppliers.ToList();

            MedicineBySupplier rpt = new MedicineBySupplier();
            rpt.Load();
            //rpt.SetDataSource(e);
            Stream s = rpt.ExportToStream(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat);
            return File(s, "C:\\Users\\M.ALI\\Documents\\ProjectAreports\\MonthlysalesReport.pdf");

        }
        public ActionResult MedicineBySupplierAction()
        {
            return MedicineBySupplier();

        }


    }
}