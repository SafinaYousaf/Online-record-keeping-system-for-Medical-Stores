﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using emed.Models;

namespace emed.Controllers
{
    public class PotenciesController : Controller
    {
        private DB53Entities db = new DB53Entities();

        // GET: Potencies
        public ActionResult Index()
        {
            return View(db.Potencies.ToList());
        }

        // GET: Potencies/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Potency potency = db.Potencies.Find(id);
            if (potency == null)
            {
                return HttpNotFound();
            }
            return View(potency);
        }

        // GET: Potencies/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Potencies/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Potency_Id,Potency_mg")] Potency potency)
        {
            if (ModelState.IsValid)
            {
                db.Potencies.Add(potency);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(potency);
        }

        // GET: Potencies/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Potency potency = db.Potencies.Find(id);
            if (potency == null)
            {
                return HttpNotFound();
            }
            return View(potency);
        }

        // POST: Potencies/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Potency_Id,Potency_mg")] Potency potency)
        {
            if (ModelState.IsValid)
            {
                db.Entry(potency).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(potency);
        }

        // GET: Potencies/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Potency potency = db.Potencies.Find(id);
            if (potency == null)
            {
                return HttpNotFound();
            }
            return View(potency);
        }

        // POST: Potencies/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {

            Potency potency = db.Potencies.Find(id);
            db.Potencies.Remove(potency);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
