﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace emed.Models
{
    public class potencyAdd
    {
        public int Potency_Id { get; set; }
        public int Potency_mg { get; set; }
    }
}